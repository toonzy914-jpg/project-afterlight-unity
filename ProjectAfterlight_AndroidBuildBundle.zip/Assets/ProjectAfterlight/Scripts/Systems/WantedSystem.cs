using UnityEngine;
using ProjectAfterlight.Input;
using ProjectAfterlight.Player;
using ProjectAfterlight.Vehicles;

namespace ProjectAfterlight.Systems
{
    public sealed class WantedSystem : MonoBehaviour
    {
        public int Level { get; private set; }
        private Transform _worldRoot;
        private MobileInput _input;
        private OrbitCamera _cameraRig;
        private VehicleController _car;
        private PlayerController _player;
        public void Configure(Transform worldRoot, MobileInput input, OrbitCamera cameraRig, VehicleController car, PlayerController player)
        {
            _worldRoot = worldRoot; _input = input; _cameraRig = cameraRig; _car = car; _player = player;
        }
        public void RaiseWanted(int amount) { Level = Mathf.Clamp(Level + amount, 0, 5); }
        public void ClearWanted() { Level = 0; }
    }
}
