using System;
using System.IO;
using UnityEngine;

namespace ProjectAfterlight.Systems
{
    public sealed class SaveSystem : MonoBehaviour
    {
        private const int CurrentVersion = 1;
        private string SavePath => Path.Combine(Application.persistentDataPath, "afterlight_save.json");

        [Serializable]
        public sealed class SaveData
        {
            public int version = CurrentVersion;
            public int money = 250;
            public bool missionCompleted;
            public string lastSavedUtc;
        }

        public SaveData Load()
        {
            try
            {
                if (!File.Exists(SavePath)) return new SaveData();
                var data = JsonUtility.FromJson<SaveData>(File.ReadAllText(SavePath));
                if (data == null || data.version != CurrentVersion) return new SaveData();
                data.money = Mathf.Max(0, data.money);
                return data;
            }
            catch (Exception ex)
            {
                Debug.LogWarning("Afterlight save could not be read; starting safe defaults. " + ex.Message);
                try { File.Copy(SavePath, SavePath + ".corrupt", true); } catch { /* Best-effort recovery copy. */ }
                return new SaveData();
            }
        }

        public bool Save(int money, bool missionCompleted)
        {
            try
            {
                var data = new SaveData { version = CurrentVersion, money = Mathf.Max(0, money), missionCompleted = missionCompleted, lastSavedUtc = DateTime.UtcNow.ToString("o") };
                string json = JsonUtility.ToJson(data, true);
                string temp = SavePath + ".tmp";
                File.WriteAllText(temp, json);
                File.Copy(temp, SavePath, true);
                File.Delete(temp);
                return true;
            }
            catch (Exception ex)
            {
                Debug.LogError("Afterlight save failed: " + ex.Message);
                return false;
            }
        }
    }
}
