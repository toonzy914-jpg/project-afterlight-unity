using UnityEngine;

namespace ProjectAfterlight.Systems
{
    public sealed class MissionSystem : MonoBehaviour
    {
        public bool Completed { get; private set; }
        private Transform _target;
        public void Initialize(Transform target, bool alreadyCompleted)
        {
            _target = target;
            Completed = alreadyCompleted;
            if (Completed && _target != null) _target.gameObject.SetActive(false);
        }
        public float DistanceTo(Transform player) => _target != null && player != null ? Vector3.Distance(player.position, _target.position) : 0f;
        public void Complete()
        {
            Completed = true;
            if (_target != null) _target.gameObject.SetActive(false);
        }
    }
}
