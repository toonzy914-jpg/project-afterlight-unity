using UnityEngine;
using ProjectAfterlight.Systems;

namespace ProjectAfterlight.AI
{
    public sealed class PoliceChaseAI : MonoBehaviour
    {
        [SerializeField] private float pursuitSpeed = 8.5f;
        [SerializeField] private float turnRate = 1.8f;
        private Transform _target;
        private WantedSystem _wanted;
        public void Configure(WantedSystem wanted) { _wanted = wanted; }
        public void SetPursuitTarget(Transform target) { _target = target; }
        private void Update()
        {
            if (_target == null || _wanted == null || _wanted.Level <= 0) return;
            Vector3 toTarget = _target.position - transform.position;
            toTarget.y = 0f;
            if (toTarget.sqrMagnitude > 0.1f)
            {
                Quaternion desired = Quaternion.LookRotation(toTarget.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, desired, turnRate * Time.deltaTime);
                transform.position += transform.forward * (pursuitSpeed * Time.deltaTime);
            }
            if (toTarget.magnitude > 110f) _wanted.ClearWanted();
        }
    }
}
