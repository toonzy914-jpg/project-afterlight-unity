using UnityEngine;
using ProjectAfterlight.Core;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace ProjectAfterlight.Input
{
    /// <summary>Keyboard/mouse and touchscreen adapter using Input System when enabled, with a legacy Input Manager fallback.</summary>
    public sealed class MobileInput : MonoBehaviour
    {
        public Vector2 MoveVector { get; private set; }
        public Vector2 LookDelta { get; private set; }
        public bool SprintHeld { get; private set; }
        public bool JumpPressed { get; private set; }
        public bool InteractPressed { get; private set; }
        public bool BrakeHeld { get; private set; }

        private bool _leftTouchActive;
        private int _leftTouchId = -1;
        private Vector2 _leftOrigin;
        private const float JoystickRadius = 90f;

        private void Update()
        {
            Vector2 move = Vector2.zero;
            bool jumpTouch = false, interactTouch = false, sprintTouch = false, brakeTouch = false;
            LookDelta = Vector2.zero;
            SprintHeld = false;
            JumpPressed = false;
            InteractPressed = false;
            BrakeHeld = false;

#if ENABLE_INPUT_SYSTEM
            var keyboard = Keyboard.current;
            if (keyboard != null)
            {
                move.x = (keyboard.dKey.isPressed ? 1f : 0f) - (keyboard.aKey.isPressed ? 1f : 0f);
                move.y = (keyboard.wKey.isPressed ? 1f : 0f) - (keyboard.sKey.isPressed ? 1f : 0f);
                SprintHeld = keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed;
                JumpPressed = keyboard.spaceKey.wasPressedThisFrame;
                InteractPressed = keyboard.eKey.wasPressedThisFrame;
                BrakeHeld = keyboard.spaceKey.isPressed;
            }
            var mouse = Mouse.current;
            if (mouse != null && mouse.rightButton.isPressed)
                LookDelta = mouse.delta.ReadValue() * 0.15f;

            var touchscreen = Touchscreen.current;
            if (touchscreen != null)
            {
                foreach (var touch in touchscreen.touches)
                {
                    var phase = touch.phase.ReadValue();
                    if (phase == UnityEngine.InputSystem.TouchPhase.None) continue;
                    Vector2 p = touch.position.ReadValue();
                    bool sprintZone = p.x < Screen.width * 0.35f && p.y > Screen.height * 0.22f && p.y < Screen.height * 0.32f;
                    bool leftZone = p.x < Screen.width * 0.46f && p.y < Screen.height * 0.58f && !sprintZone;
                    bool jumpZone = p.x > Screen.width * 0.80f && p.y > Screen.height * 0.13f && p.y < Screen.height * 0.25f;
                    bool interactZone = p.x > Screen.width * 0.80f && p.y > Screen.height * 0.04f && p.y <= Screen.height * 0.13f;
                    bool brakeZone = p.x > Screen.width * 0.83f && p.y > Screen.height * 0.30f && p.y < Screen.height * 0.55f;
                    if (!_leftTouchActive && leftZone && phase == UnityEngine.InputSystem.TouchPhase.Began)
                    {
                        _leftTouchActive = true; _leftTouchId = touch.touchId.ReadValue(); _leftOrigin = p;
                    }
                    if (_leftTouchActive && touch.touchId.ReadValue() == _leftTouchId)
                        move = Vector2.ClampMagnitude((p - _leftOrigin) / JoystickRadius, 1f);
                    if (phase == UnityEngine.InputSystem.TouchPhase.Began && jumpZone) jumpTouch = true;
                    if (phase == UnityEngine.InputSystem.TouchPhase.Began && interactZone) interactTouch = true;
                    if (sprintZone && touch.press.isPressed) sprintTouch = true;
                    if (brakeZone && touch.press.isPressed) brakeTouch = true;
                    bool rightLookZone = p.x > Screen.width * 0.47f && p.y < Screen.height * 0.68f && !jumpZone && !interactZone && !brakeZone;
                    if (rightLookZone && phase == UnityEngine.InputSystem.TouchPhase.Moved) LookDelta += touch.delta.ReadValue() * 0.04f;
                    if (phase == UnityEngine.InputSystem.TouchPhase.Ended || phase == UnityEngine.InputSystem.TouchPhase.Canceled)
                    {
                        if (touch.touchId.ReadValue() == _leftTouchId) { _leftTouchActive = false; _leftTouchId = -1; }
                    }
                }
            }
#elif ENABLE_LEGACY_INPUT_MANAGER
            move.x = UnityEngine.Input.GetAxisRaw("Horizontal");
            move.y = UnityEngine.Input.GetAxisRaw("Vertical");
            if (UnityEngine.Input.GetKey(KeyCode.A)) move.x = -1f;
            if (UnityEngine.Input.GetKey(KeyCode.D)) move.x = 1f;
            if (UnityEngine.Input.GetKey(KeyCode.S)) move.y = -1f;
            if (UnityEngine.Input.GetKey(KeyCode.W)) move.y = 1f;
            SprintHeld = UnityEngine.Input.GetKey(KeyCode.LeftShift);
            JumpPressed = UnityEngine.Input.GetKeyDown(KeyCode.Space);
            InteractPressed = UnityEngine.Input.GetKeyDown(KeyCode.E);
            BrakeHeld = UnityEngine.Input.GetKey(KeyCode.Space);
            LookDelta = UnityEngine.Input.GetMouseButton(1) ? new Vector2(UnityEngine.Input.GetAxis("Mouse X"), UnityEngine.Input.GetAxis("Mouse Y")) * 3f : Vector2.zero;
            for (int i = 0; i < UnityEngine.Input.touchCount; i++)
            {
                Touch touch = UnityEngine.Input.GetTouch(i);
                Vector2 p = touch.position;
                bool sprintZone = p.x < Screen.width * 0.35f && p.y > Screen.height * 0.22f && p.y < Screen.height * 0.32f;
                bool leftZone = p.x < Screen.width * 0.46f && p.y < Screen.height * 0.58f && !sprintZone;
                bool jumpZone = p.x > Screen.width * 0.80f && p.y > Screen.height * 0.13f && p.y < Screen.height * 0.25f;
                bool interactZone = p.x > Screen.width * 0.80f && p.y > Screen.height * 0.04f && p.y <= Screen.height * 0.13f;
                bool brakeZone = p.x > Screen.width * 0.83f && p.y > Screen.height * 0.30f && p.y < Screen.height * 0.55f;
                if (!_leftTouchActive && leftZone && touch.phase == TouchPhase.Began)
                {
                    _leftTouchActive = true; _leftTouchId = touch.fingerId; _leftOrigin = p;
                }
                if (_leftTouchActive && touch.fingerId == _leftTouchId)
                    move = Vector2.ClampMagnitude((p - _leftOrigin) / JoystickRadius, 1f);
                if (touch.phase == TouchPhase.Began && jumpZone) jumpTouch = true;
                if (touch.phase == TouchPhase.Began && interactZone) interactTouch = true;
                if (sprintZone && touch.phase != TouchPhase.Ended && touch.phase != TouchPhase.Canceled) sprintTouch = true;
                if (brakeZone && touch.phase != TouchPhase.Ended && touch.phase != TouchPhase.Canceled) brakeTouch = true;
                bool rightLookZone = p.x > Screen.width * 0.47f && p.y < Screen.height * 0.68f && !jumpZone && !interactZone && !brakeZone;
                if (rightLookZone && touch.phase == TouchPhase.Moved) LookDelta += touch.deltaPosition * 0.04f;
                if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
                    if (touch.fingerId == _leftTouchId) { _leftTouchActive = false; _leftTouchId = -1; }
            }
#endif
            if (sprintTouch) SprintHeld = true;
            if (brakeTouch) BrakeHeld = true;
            JumpPressed |= jumpTouch;
            InteractPressed |= interactTouch;
            MoveVector = Vector2.ClampMagnitude(move, 1f);
        }

        private void OnGUI()
        {
            float scale = Mathf.Clamp(Screen.width / 900f, 0.72f, 1.25f);
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(scale, scale, 1f));
            float width = Screen.width / scale;
            float height = Screen.height / scale;
            GUI.color = new Color(0.025f, 0.06f, 0.07f, 0.78f);
            GUI.Box(new Rect(18, 18, 510, 90), GUIContent.none);
            GUI.color = new Color(0.36f, 0.95f, 0.82f, 1f);
            GUI.Label(new Rect(32, 25, 490, 28), "PROJECT AFTERLIGHT  /  VERTICAL SLICE");
            GUI.color = Color.white;
            GUI.Label(new Rect(32, 51, 490, 25), GameBootstrap.Instance != null ? GameBootstrap.Instance.ObjectiveText() : "Initializing city...");
            GUI.Label(new Rect(32, 75, 490, 22), GameBootstrap.Instance != null ? "$" + GameBootstrap.Instance.Money + "   •   " + GameBootstrap.Instance.VehicleText() : "WASD move  |  Mouse-right drag look  |  E interact");

            // Mobile control hints and touch zones.
            GUI.color = new Color(0.8f, 0.9f, 0.9f, 0.4f);
            GUI.Box(new Rect(30, height - 188, 150, 150), "MOVE");
            GUI.Box(new Rect(width - 186, height - 188, 156, 62), "JUMP");
            GUI.Box(new Rect(width - 186, height - 112, 156, 62), "INTERACT / CAR");
            GUI.Box(new Rect(width - 186, height * 0.46f, 156, 62), "BRAKE");
            GUI.Box(new Rect(30, height - 230, 150, 30), "HOLD: SPRINT");
            GUI.color = Color.white;
            GUI.Label(new Rect(width - 300, 22, 280, 42), "Swipe right side to look around");
            GUI.matrix = Matrix4x4.identity;
        }
    }
}
