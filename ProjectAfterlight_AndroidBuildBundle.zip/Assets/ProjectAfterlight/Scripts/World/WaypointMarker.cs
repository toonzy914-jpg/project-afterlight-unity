using UnityEngine;

namespace ProjectAfterlight.World
{
    public sealed class WaypointMarker : MonoBehaviour
    {
        private Transform _beacon;
        private void Awake()
        {
            if (transform.childCount > 1) _beacon = transform.GetChild(1);
        }
        private void Update()
        {
            if (_beacon != null)
            {
                var p = _beacon.localPosition;
                p.y = 1.45f + Mathf.Sin(Time.time * 2.2f) * 0.16f;
                _beacon.localPosition = p;
                _beacon.Rotate(Vector3.up, 50f * Time.deltaTime, Space.Self);
            }
        }
    }
}
