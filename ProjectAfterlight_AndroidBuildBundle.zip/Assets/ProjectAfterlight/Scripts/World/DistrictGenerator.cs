using UnityEngine;
using ProjectAfterlight.Vehicles;

namespace ProjectAfterlight.World
{
    public static class DistrictGenerator
    {
        private static readonly Color Asphalt = new Color(0.075f, 0.09f, 0.105f);
        private static readonly Color Sidewalk = new Color(0.25f, 0.28f, 0.29f);
        private static readonly Color WindowGlow = new Color(1f, 0.68f, 0.32f);

        public static void Build(Transform root)
        {
            var ground = Cube("District Ground", root, new Vector3(0f, -0.42f, 0f), new Vector3(190f, 0.7f, 190f), MakeMaterial("Ground - Slate", new Color(0.16f, 0.20f, 0.20f)));
            ground.isStatic = true;
            var road = MakeMaterial("Road Asphalt", Asphalt);
            var sidewalk = MakeMaterial("Sidewalk Concrete", Sidewalk);
            var lane = MakeMaterial("Lane Paint", new Color(0.78f, 0.77f, 0.66f));

            // Original compact district: five parallel road lines in both directions.
            for (int i = -2; i <= 2; i++)
            {
                float c = i * 38f;
                Cube("Road_NS_" + i, root, new Vector3(c, -0.02f, 0f), new Vector3(12f, 0.12f, 180f), road).isStatic = true;
                Cube("Road_EW_" + i, root, new Vector3(0f, -0.015f, c), new Vector3(180f, 0.12f, 12f), road).isStatic = true;
                Cube("Walk_NS_A_" + i, root, new Vector3(c - 7f, 0.02f, 0f), new Vector3(2f, 0.16f, 180f), sidewalk).isStatic = true;
                Cube("Walk_NS_B_" + i, root, new Vector3(c + 7f, 0.02f, 0f), new Vector3(2f, 0.16f, 180f), sidewalk).isStatic = true;
                Cube("Walk_EW_A_" + i, root, new Vector3(0f, 0.02f, c - 7f), new Vector3(180f, 0.16f, 2f), sidewalk).isStatic = true;
                Cube("Walk_EW_B_" + i, root, new Vector3(0f, 0.02f, c + 7f), new Vector3(180f, 0.16f, 2f), sidewalk).isStatic = true;
            }
            for (int i = -8; i <= 8; i++)
            {
                float p = i * 10f;
                Cube("LaneMark_NS_" + i, root, new Vector3(0f, 0.055f, p), new Vector3(0.18f, 0.025f, 4.2f), lane).isStatic = true;
                Cube("LaneMark_EW_" + i, root, new Vector3(p, 0.055f, 0f), new Vector3(4.2f, 0.025f, 0.18f), lane).isStatic = true;
            }

            var rng = new System.Random(2100);
            var buildingColors = new[] {
                new Color(0.22f,0.28f,0.31f), new Color(0.30f,0.31f,0.30f),
                new Color(0.27f,0.24f,0.24f), new Color(0.18f,0.29f,0.30f),
                new Color(0.35f,0.31f,0.26f)
            };
            var windowMat = MakeEmissiveMaterial("Warm Office Windows", WindowGlow);
            int id = 0;
            float[] centers = { -57f, -19f, 19f, 57f };
            for (int ix = 0; ix < centers.Length; ix++)
            for (int iz = 0; iz < centers.Length; iz++)
            {
                id++;
                float x = centers[ix];
                float z = centers[iz];
                float w = 12f + (float)rng.NextDouble() * 5f;
                float d = 12f + (float)rng.NextDouble() * 5f;
                float h = 9f + (float)rng.NextDouble() * 20f;
                bool workshop = ix == 2 && iz == 2;
                if (workshop) { w = 14f; d = 14f; h = 8f; }
                var mat = MakeMaterial(workshop ? "Echo Garage Paint" : "Facade " + id, workshop ? new Color(0.18f, 0.30f, 0.30f) : buildingColors[rng.Next(buildingColors.Length)]);
                var building = Cube(workshop ? "ECHO GARAGE Building" : "Building_" + id, root, new Vector3(x, h * 0.5f, z), new Vector3(w, h, d), mat);
                building.isStatic = true;
                if (!workshop)
                    AddWindows(root, x, z, w, d, h, windowMat, id);
                else
                    AddWorkshopSign(root, x, z, h);
                // Roof service units create a readable silhouette without expensive meshes.
                if (!workshop && id % 3 == 0)
                    Cube("Roof HVAC " + id, root, new Vector3(x + w * 0.18f, h + 0.65f, z), new Vector3(2.2f, 1.3f, 2.6f), MakeMaterial("HVAC Metal", new Color(0.12f, 0.15f, 0.17f))).isStatic = true;
            }

            CreateStreetLights(root);
            AddDistrictSign(root);
            // Batch the stationary city meshes; moving actors and vehicles are created afterwards.
            try { StaticBatchingUtility.Combine(root.gameObject); }
            catch (System.Exception ex) { Debug.LogWarning("City static batching skipped; continuing without it. " + ex.Message); }
        }

        private static void AddWindows(Transform root, float x, float z, float w, float d, float h, Material material, int seed)
        {
            int floors = Mathf.Clamp(Mathf.FloorToInt(h / 4f), 2, 6);
            int columns = 3;
            float yStart = 2.2f;
            for (int floor = 0; floor < floors; floor++)
            {
                float y = yStart + floor * 3.2f;
                if (y > h - 1f) break;
                for (int c = 0; c < columns; c++)
                {
                    float offsetX = (c - 1) * (w / 4f);
                    // Front and back windows.
                    DecorationCube("Window", root, new Vector3(x + offsetX, y, z - d * 0.5f - 0.035f), new Vector3(0.78f, 1.05f, 0.07f), material).isStatic = true;
                    DecorationCube("Window", root, new Vector3(x + offsetX, y, z + d * 0.5f + 0.035f), new Vector3(0.78f, 1.05f, 0.07f), material).isStatic = true;
                    // Side windows.
                    float offsetZ = (c - 1) * (d / 4f);
                    DecorationCube("Window", root, new Vector3(x - w * 0.5f - 0.035f, y, z + offsetZ), new Vector3(0.07f, 1.05f, 0.78f), material).isStatic = true;
                    DecorationCube("Window", root, new Vector3(x + w * 0.5f + 0.035f, y, z + offsetZ), new Vector3(0.07f, 1.05f, 0.78f), material).isStatic = true;
                }
            }
        }

        private static void AddWorkshopSign(Transform root, float x, float z, float h)
        {
            var sign = Cube("ECHO GARAGE Sign Plate", root, new Vector3(x, h - 1.0f, z - 7.12f), new Vector3(8.2f, 1.15f, 0.16f), MakeEmissiveMaterial("Garage Sign Teal", new Color(0.12f, 0.85f, 0.75f)));
            sign.name = "ECHO GARAGE — mission location";
            sign.isStatic = true;
            Cube("Garage Door", root, new Vector3(x, 2.1f, z - 7.12f), new Vector3(5.2f, 3.8f, 0.16f), MakeMaterial("Garage Door", new Color(0.055f, 0.075f, 0.08f))).isStatic = true;
        }

        private static void CreateStreetLights(Transform root)
        {
            var poleMat = MakeMaterial("Street Lamp Metal", new Color(0.08f, 0.11f, 0.12f), 0.45f);
            var lampMat = MakeEmissiveMaterial("Street Lamp Amber", new Color(1f, 0.62f, 0.25f));
            int index = 0;
            for (int p = -2; p <= 2; p++)
            for (int k = -4; k <= 4; k += 2)
            {
                if (Mathf.Abs(p) == 0 && Mathf.Abs(k) < 2) continue;
                float x = p * 38f + 8.2f;
                float z = k * 10f;
                Cube("Lamp Pole " + index, root, new Vector3(x, 2.6f, z), new Vector3(0.16f, 5.2f, 0.16f), poleMat).isStatic = true;
                Cube("Lamp Head " + index, root, new Vector3(x, 5.25f, z + 0.55f), new Vector3(0.75f, 0.18f, 0.45f), lampMat).isStatic = true;
                index++;
            }
        }

        private static void AddDistrictSign(Transform root)
        {
            var post = MakeMaterial("Sign Post", new Color(0.075f, 0.09f, 0.10f));
            var face = MakeEmissiveMaterial("District Sign", new Color(0.1f, 0.4f, 0.44f));
            Cube("AFTERLIGHT District Marker Post", root, new Vector3(-8f, 1.45f, 13f), new Vector3(0.2f, 2.9f, 0.2f), post).isStatic = true;
            Cube("AFTERLIGHT District Marker", root, new Vector3(-8f, 2.45f, 13f), new Vector3(3.5f, 1.2f, 0.18f), face).isStatic = true;
        }

        public static Transform CreateMissionLocation(Transform root)
        {
            var markerRoot = new GameObject("Mission_Target_EchoGarage").transform;
            markerRoot.SetParent(root, false);
            markerRoot.position = new Vector3(10.5f, 0f, 18.5f);
            var ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            ring.name = "Mission Marker Ring";
            ring.transform.SetParent(markerRoot, false);
            ring.transform.localPosition = new Vector3(0f, 0.12f, 0f);
            ring.transform.localScale = new Vector3(1.7f, 0.08f, 1.7f);
            ring.GetComponent<Renderer>().material = MakeEmissiveMaterial("Mission Marker Cyan", new Color(0.05f, 0.9f, 0.75f));
            Object.Destroy(ring.GetComponent<Collider>());
            var orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            orb.name = "Mission Marker Beacon";
            orb.transform.SetParent(markerRoot, false);
            orb.transform.localPosition = new Vector3(0f, 1.55f, 0f);
            orb.transform.localScale = Vector3.one * 0.45f;
            orb.GetComponent<Renderer>().material = MakeEmissiveMaterial("Mission Beacon", new Color(0.1f, 0.95f, 0.8f));
            Object.Destroy(orb.GetComponent<Collider>());
            markerRoot.gameObject.AddComponent<WaypointMarker>();
            return markerRoot;
        }

        public static VehicleController CreateCar(Transform root, string name, Vector3 position, Color color)
        {
            var carRoot = new GameObject(name);
            carRoot.transform.SetParent(root, false);
            carRoot.transform.position = position;
            var bodyMat = MakeMaterial(name + " Paint", color, 0.35f);
            var glassMat = MakeMaterial("Vehicle Glass", new Color(0.055f, 0.12f, 0.14f), 0.1f);
            DecorationCube("Car Chassis", carRoot.transform, new Vector3(0f, 0.68f, 0f), new Vector3(1.85f, 0.55f, 3.9f), bodyMat);
            DecorationCube("Car Cabin", carRoot.transform, new Vector3(0f, 1.12f, -0.18f), new Vector3(1.48f, 0.58f, 1.85f), glassMat);
            DecorationCube("Car Hood", carRoot.transform, new Vector3(0f, 0.91f, 1.24f), new Vector3(1.72f, 0.18f, 0.95f), bodyMat);
            DecorationCube("Car Front Bumper", carRoot.transform, new Vector3(0f, 0.43f, 2.0f), new Vector3(1.78f, 0.17f, 0.16f), glassMat);
            DecorationCube("Car Rear Bumper", carRoot.transform, new Vector3(0f, 0.43f, -2.0f), new Vector3(1.78f, 0.17f, 0.16f), glassMat);
            var wheelMat = MakeMaterial("Rubber", new Color(0.025f, 0.03f, 0.035f));
            for (int side = -1; side <= 1; side += 2)
            for (int axle = -1; axle <= 1; axle += 2)
            {
                var wheel = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                wheel.name = "Wheel";
                wheel.transform.SetParent(carRoot.transform, false);
                wheel.transform.localPosition = new Vector3(side * 0.92f, 0.42f, axle * 1.28f);
                wheel.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                wheel.transform.localScale = new Vector3(0.48f, 0.19f, 0.48f);
                wheel.GetComponent<Renderer>().material = wheelMat;
                Object.Destroy(wheel.GetComponent<Collider>());
            }
            var collider = carRoot.AddComponent<BoxCollider>();
            collider.center = new Vector3(0f, 0.72f, 0f);
            collider.size = new Vector3(1.95f, 1.2f, 4.05f);
            var rb = carRoot.AddComponent<Rigidbody>();
            rb.mass = 1250f;
            rb.drag = 0.15f;
            rb.angularDrag = 1.8f;
            rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            return carRoot.AddComponent<VehicleController>();
        }

        public static VehicleController CreatePoliceCar(Transform root, Vector3 position)
        {
            var car = CreateCar(root, "Aster County Patrol", position, new Color(0.08f, 0.12f, 0.17f));
            var lightbar = DecorationCube("Police Lightbar", car.transform, new Vector3(0f, 1.5f, -0.15f), new Vector3(0.9f, 0.13f, 0.25f), MakeEmissiveMaterial("Police Light Blue", new Color(0.12f, 0.35f, 1f)));
            lightbar.name = "Police Lightbar Blue";
            car.enabled = false;
            var body = car.gameObject.GetComponent<Rigidbody>();
            if (body != null) body.isKinematic = true;
            return car;
        }

        public static void CreateTrafficCar(Transform root, string name, Vector3 position, Vector3 direction, float speed, Color color)
        {
            var traffic = new GameObject(name);
            traffic.transform.SetParent(root, false);
            traffic.transform.position = position;
            traffic.transform.rotation = Quaternion.LookRotation(direction, Vector3.up);
            var mat = MakeMaterial(name + " Body", color, 0.2f);
            var glass = MakeMaterial("Traffic Glass", new Color(0.06f, 0.09f, 0.11f));
            DecorationCube("Traffic Body", traffic.transform, new Vector3(0f, 0.65f, 0f), new Vector3(1.55f, 0.52f, 3.25f), mat);
            DecorationCube("Traffic Cabin", traffic.transform, new Vector3(0f, 1.04f, -0.15f), new Vector3(1.25f, 0.45f, 1.55f), glass);
            traffic.AddComponent<TrafficMover>().Configure(direction, speed, -88f, 88f);
        }

        public static Material MakeMaterial(string name, Color color, float metallic = 0f)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            var material = new Material(shader) { name = name, color = color };
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            return material;
        }

        private static Material MakeEmissiveMaterial(string name, Color color)
        {
            var material = MakeMaterial(name, color);
            if (material.HasProperty("_EmissionColor"))
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor("_EmissionColor", color * 1.25f);
            }
            return material;
        }

        private static GameObject DecorationCube(string name, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            var go = Cube(name, parent, position, scale, material);
            var collider = go.GetComponent<Collider>();
            if (collider != null) Object.Destroy(collider);
            return go;
        }

        private static GameObject Cube(string name, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = material;
            return go;
        }
    }
}
