using UnityEngine;

namespace ProjectAfterlight.World
{
    public sealed class DayNightCycle : MonoBehaviour
    {
        [SerializeField] private float fullCycleSeconds = 900f;
        private Light _sun;
        private void Awake() => _sun = GetComponent<Light>();
        private void Update()
        {
            float phase = (Time.time / Mathf.Max(30f, fullCycleSeconds)) * 360f;
            transform.rotation = Quaternion.Euler(35f + Mathf.Sin(phase * Mathf.Deg2Rad) * 24f, -32f + phase * 0.45f, 0f);
            if (_sun != null) _sun.intensity = Mathf.Lerp(0.18f, 1.15f, Mathf.Clamp01((Mathf.Sin((phase - 90f) * Mathf.Deg2Rad) + 1f) * 0.5f));
        }
    }
}
