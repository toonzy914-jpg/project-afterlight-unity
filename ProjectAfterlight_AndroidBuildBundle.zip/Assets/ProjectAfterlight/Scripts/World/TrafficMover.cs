using UnityEngine;

namespace ProjectAfterlight.World
{
    public sealed class TrafficMover : MonoBehaviour
    {
        private Vector3 _direction;
        private float _speed;
        private float _min;
        private float _max;
        public void Configure(Vector3 direction, float speed, float min, float max)
        {
            _direction = direction.normalized;
            _speed = speed;
            _min = min;
            _max = max;
        }
        private void Update()
        {
            transform.position += _direction * (_speed * Time.deltaTime);
            if (_direction.z > 0f && transform.position.z > _max) transform.position = new Vector3(transform.position.x, transform.position.y, _min);
            else if (_direction.z < 0f && transform.position.z < _min) transform.position = new Vector3(transform.position.x, transform.position.y, _max);
            else if (_direction.x > 0f && transform.position.x > _max) transform.position = new Vector3(_min, transform.position.y, transform.position.z);
            else if (_direction.x < 0f && transform.position.x < _min) transform.position = new Vector3(_max, transform.position.y, transform.position.z);
        }
    }
}
