using UnityEngine;
using ProjectAfterlight.World;
using ProjectAfterlight.Player;
using ProjectAfterlight.Input;
using ProjectAfterlight.Vehicles;
using ProjectAfterlight.AI;
using ProjectAfterlight.Systems;

namespace ProjectAfterlight.Core
{
    /// <summary>Builds the vertical-slice demo at runtime so the project has no external asset dependency.</summary>
    public sealed class GameBootstrap : MonoBehaviour
    {
        public static GameBootstrap Instance { get; private set; }
        public Transform PlayerTransform => _player != null && _player.gameObject.activeInHierarchy ? _player.transform : (_car != null && _car.IsOccupied ? _car.transform : null);
        public int Money { get; private set; } = 250;
        public string StatusMessage { get; private set; } = "Reach ECHO GARAGE and recover the data drive.";
        public float MissionDistance => _missionTarget != null && PlayerTransform != null ? Vector3.Distance(PlayerTransform.position, _missionTarget.position) : 0f;

        private Transform _worldRoot;
        private PlayerController _player;
        private OrbitCamera _cameraRig;
        private MobileInput _input;
        private VehicleController _car;
        private Transform _missionTarget;
        private MissionSystem _mission;
        private SaveSystem _save;
        private WantedSystem _wanted;
        private PoliceChaseAI _police;
        private Light _sun;

        private void Awake()
        {
            Instance = this;
            _input = GetComponent<MobileInput>() ?? gameObject.AddComponent<MobileInput>();
            _save = GetComponent<SaveSystem>() ?? gameObject.AddComponent<SaveSystem>();
            _mission = GetComponent<MissionSystem>() ?? gameObject.AddComponent<MissionSystem>();
            _wanted = GetComponent<WantedSystem>() ?? gameObject.AddComponent<WantedSystem>();
        }

        private void Start()
        {
            Application.targetFrameRate = Application.isMobilePlatform ? 30 : 60;
            QualitySettings.vSyncCount = 0;
            QualitySettings.shadowDistance = 55f;

            var saveData = _save.Load();
            Money = saveData.money;
            _worldRoot = new GameObject("AFTERLIGHT_GENERATED_WORLD").transform;
            DistrictGenerator.Build(_worldRoot);
            CreatePlayerAndCamera();
            CreateVehicles();
            _missionTarget = DistrictGenerator.CreateMissionLocation(_worldRoot);
            _mission.Initialize(_missionTarget, saveData.missionCompleted);
            if (saveData.missionCompleted)
                StatusMessage = "Mission complete. Explore the district or drive around.";
            CreateTraffic();
            CreateSun();
        }

        private void CreatePlayerAndCamera()
        {
            var playerRoot = new GameObject("Player_Prototype");
            playerRoot.transform.SetParent(_worldRoot, false);
            playerRoot.transform.position = new Vector3(-5f, 0.1f, 8f);
            var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "PlayerBody_Prototype";
            body.transform.SetParent(playerRoot.transform, false);
            body.transform.localPosition = new Vector3(0f, 1f, 0f);
            body.transform.localScale = new Vector3(0.66f, 0.92f, 0.5f);
            body.GetComponent<Renderer>().material = DistrictGenerator.MakeMaterial("Player Jacket", new Color(0.08f, 0.22f, 0.28f));
            Destroy(body.GetComponent<Collider>());
            var head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            head.name = "PlayerHead_Prototype";
            head.transform.SetParent(playerRoot.transform, false);
            head.transform.localPosition = new Vector3(0f, 2.05f, 0f);
            head.transform.localScale = Vector3.one * 0.34f;
            head.GetComponent<Renderer>().material = DistrictGenerator.MakeMaterial("Warm Skin", new Color(0.57f, 0.37f, 0.25f));
            Destroy(head.GetComponent<Collider>());
            var cc = playerRoot.AddComponent<CharacterController>();
            cc.height = 2.0f;
            cc.radius = 0.38f;
            cc.center = new Vector3(0f, 1f, 0f);
            _player = playerRoot.AddComponent<PlayerController>();
            _player.Configure(_input);

            var camObject = new GameObject("Main Camera");
            camObject.tag = "MainCamera";
            var cam = camObject.AddComponent<Camera>();
            cam.fieldOfView = 66f;
            cam.nearClipPlane = 0.1f;
            cam.farClipPlane = 260f;
            camObject.AddComponent<AudioListener>();
            _cameraRig = camObject.AddComponent<OrbitCamera>();
            _cameraRig.SetTarget(playerRoot.transform);
        }

        private void CreateVehicles()
        {
            _car = DistrictGenerator.CreateCar(_worldRoot, "Street Coupe", new Vector3(4f, 0.1f, 8f), new Color(0.08f, 0.34f, 0.38f));
            _car.Configure(_input, _cameraRig, _player, _wanted);
            _wanted.Configure(_worldRoot, _input, _cameraRig, _car, _player);
        }

        private void CreateTraffic()
        {
            DistrictGenerator.CreateTrafficCar(_worldRoot, "Traffic Northbound", new Vector3(-2.2f, 0.1f, -45f), Vector3.forward, 4.2f, new Color(0.56f, 0.26f, 0.17f));
            DistrictGenerator.CreateTrafficCar(_worldRoot, "Traffic Eastbound", new Vector3(-65f, 0.1f, 2.2f), Vector3.right, 3.5f, new Color(0.62f, 0.62f, 0.55f));
            DistrictGenerator.CreateTrafficCar(_worldRoot, "Traffic Southbound", new Vector3(2.2f, 0.1f, 62f), Vector3.back, 3.8f, new Color(0.18f, 0.30f, 0.52f));
        }

        private void CreateSun()
        {
            var lightObject = new GameObject("AFTERLIGHT_SUN");
            _sun = lightObject.AddComponent<Light>();
            _sun.type = LightType.Directional;
            _sun.intensity = 1.1f;
            _sun.color = new Color(1f, 0.86f, 0.72f);
            _sun.shadows = LightShadows.Soft;
            lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
            lightObject.AddComponent<DayNightCycle>();
        }

        private void Update()
        {
            if (_input == null || _player == null || _car == null) return;

            if (_input.InteractPressed)
            {
                if (_car.IsOccupied)
                {
                    _car.ExitVehicle();
                }
                else if (Vector3.Distance(_player.transform.position, _car.transform.position) < 4.2f)
                {
                    _car.EnterVehicle();
                    StatusMessage = "Vehicle acquired. Reach the garage marker on foot or by car.";
                }
                else if (!_mission.Completed && _missionTarget != null && Vector3.Distance(_player.transform.position, _missionTarget.position) < 4.5f)
                {
                    _mission.Complete();
                    Money += 500;
                    StatusMessage = "DATA DRIVE RECOVERED — +$500";
                    _save.Save(Money, true);
                }
            }

            if (_wanted.Level > 0 && _police == null)
                SpawnPolice();
            if (_police != null && _police.gameObject != null)
                _police.SetPursuitTarget(PlayerTransform);

            if (Time.frameCount % 300 == 0)
                _save.Save(Money, _mission.Completed);
        }

        private void SpawnPolice()
        {
            var police = DistrictGenerator.CreatePoliceCar(_worldRoot, new Vector3(-18f, 0.1f, -12f));
            _police = police.gameObject.AddComponent<PoliceChaseAI>();
            _police.Configure(_wanted);
            _police.SetPursuitTarget(PlayerTransform);
            StatusMessage = "POLICE ALERT — break line of sight.";
        }

        public string ObjectiveText()
        {
            if (_mission != null && _mission.Completed) return "MISSION COMPLETE  |  Free roam";
            if (_missionTarget == null) return "Preparing district...";
            return $"OBJECTIVE: Reach ECHO GARAGE  |  {_mission.DistanceTo(PlayerTransform):0} m";
        }

        public string VehicleText() => _car != null && _car.IsOccupied ? "DRIVING  •  E: Exit vehicle" : "WASD / joystick to move  •  E: interact / enter";

        private void OnApplicationPause(bool paused)
        {
            if (paused && _save != null && _mission != null) _save.Save(Money, _mission.Completed);
        }

        private void OnApplicationQuit()
        {
            if (_save != null && _mission != null) _save.Save(Money, _mission.Completed);
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }
    }
}
