using UnityEngine;
using ProjectAfterlight.Input;
using ProjectAfterlight.Player;
using ProjectAfterlight.AI;

namespace ProjectAfterlight.Vehicles
{
    [RequireComponent(typeof(Rigidbody), typeof(BoxCollider))]
    public sealed class VehicleController : MonoBehaviour
    {
        [SerializeField] private float acceleration = 12f;
        [SerializeField] private float maxSpeed = 22f;
        [SerializeField] private float reverseSpeed = 7f;
        [SerializeField] private float steeringDegreesPerSecond = 74f;
        private Rigidbody _body;
        private MobileInput _input;
        private OrbitCamera _cameraRig;
        private PlayerController _player;
        private WantedSystem _wanted;
        private float _drive;
        private float _steer;
        public bool IsOccupied { get; private set; }
        public float Speed => _body != null ? _body.velocity.magnitude : 0f;

        private void Awake() { _body = GetComponent<Rigidbody>(); }
        public void Configure(MobileInput input, OrbitCamera cameraRig, PlayerController player, WantedSystem wanted)
        {
            _input = input; _cameraRig = cameraRig; _player = player; _wanted = wanted;
        }
        public void EnterVehicle()
        {
            if (IsOccupied || _player == null || _cameraRig == null) return;
            IsOccupied = true;
            _player.gameObject.SetActive(false);
            _drive = 0f; _steer = 0f;
            if (_wanted != null) _wanted.RaiseWanted(1);
            _cameraRig.SetTarget(transform);
        }
        public void ExitVehicle()
        {
            if (!IsOccupied || _player == null || _cameraRig == null) return;
            IsOccupied = false;
            _player.transform.position = transform.position - transform.right * 1.9f + Vector3.up * 0.15f;
            _player.transform.rotation = Quaternion.LookRotation(-transform.right, Vector3.up);
            _player.gameObject.SetActive(true);
            _cameraRig.SetTarget(_player.transform);
            _body.velocity = new Vector3(_body.velocity.x * 0.35f, _body.velocity.y, _body.velocity.z * 0.35f);
        }
        private void FixedUpdate()
        {
            if (_body == null) return;
            if (!IsOccupied)
            {
                _body.drag = 0.15f;
                return;
            }
            _drive = _input != null ? _input.MoveVector.y : 0f;
            _steer = _input != null ? _input.MoveVector.x : 0f;
            bool brake = _input != null && _input.BrakeHeld;
            float forwardSpeed = Vector3.Dot(_body.velocity, transform.forward);
            float cap = _drive < -0.05f ? reverseSpeed : maxSpeed;
            if (!brake && Mathf.Abs(forwardSpeed) < cap)
                _body.AddForce(transform.forward * (_drive * acceleration), ForceMode.Acceleration);
            if (brake) _body.velocity = Vector3.Lerp(_body.velocity, new Vector3(0f, _body.velocity.y, 0f), Time.fixedDeltaTime * 2.4f);
            if (Mathf.Abs(forwardSpeed) > 0.5f)
            {
                float direction = forwardSpeed >= 0f ? 1f : -1f;
                Quaternion turn = Quaternion.Euler(0f, _steer * steeringDegreesPerSecond * direction * Time.fixedDeltaTime, 0f);
                _body.MoveRotation(_body.rotation * turn);
            }
        }
    }
}
