using UnityEngine;
using ProjectAfterlight.Input;

namespace ProjectAfterlight.Player
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerController : MonoBehaviour
    {
        [SerializeField] private float walkSpeed = 4.6f;
        [SerializeField] private float sprintSpeed = 7.2f;
        [SerializeField] private float jumpHeight = 1.15f;
        [SerializeField] private float gravity = -20f;
        private CharacterController _controller;
        private MobileInput _input;
        private float _verticalSpeed;
        public void Configure(MobileInput input) { _input = input; _controller = GetComponent<CharacterController>(); }
        private void Awake() { _controller = GetComponent<CharacterController>(); }
        private void Update()
        {
            if (_input == null || !_controller.enabled) return;
            Vector2 raw = _input.MoveVector;
            Transform cam = Camera.main != null ? Camera.main.transform : null;
            Vector3 forward = cam != null ? Vector3.ProjectOnPlane(cam.forward, Vector3.up).normalized : Vector3.forward;
            Vector3 right = cam != null ? Vector3.ProjectOnPlane(cam.right, Vector3.up).normalized : Vector3.right;
            Vector3 move = Vector3.ClampMagnitude(forward * raw.y + right * raw.x, 1f);
            float speed = _input.SprintHeld ? sprintSpeed : walkSpeed;
            if (move.sqrMagnitude > 0.01f)
            {
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(move, Vector3.up), 12f * Time.deltaTime);
            }
            if (_controller.isGrounded && _verticalSpeed < 0f) _verticalSpeed = -2f;
            if (_input.JumpPressed && _controller.isGrounded) _verticalSpeed = Mathf.Sqrt(jumpHeight * -2f * gravity);
            _verticalSpeed += gravity * Time.deltaTime;
            Vector3 velocity = move * speed;
            velocity.y = _verticalSpeed;
            _controller.Move(velocity * Time.deltaTime);
        }
    }
}
