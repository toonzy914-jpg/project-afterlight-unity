using UnityEngine;
using ProjectAfterlight.Input;

namespace ProjectAfterlight.Player
{
    public sealed class OrbitCamera : MonoBehaviour
    {
        [SerializeField] private float distance = 5.3f;
        [SerializeField] private float sensitivity = 2.2f;
        [SerializeField] private float minPitch = -18f;
        [SerializeField] private float maxPitch = 68f;
        private Transform _target;
        private MobileInput _input;
        private float _yaw;
        private float _pitch = 16f;
        public void SetTarget(Transform target) { _target = target; if (_target != null) _yaw = _target.eulerAngles.y; }
        private void Start() { _input = FindFirstObjectByType<MobileInput>(); }
        private void LateUpdate()
        {
            if (_target == null) return;
            if (_input != null)
            {
                Vector2 look = _input.LookDelta;
                _yaw += look.x * sensitivity;
                _pitch = Mathf.Clamp(_pitch - look.y * sensitivity, minPitch, maxPitch);
            }
            float targetHeight = _target.GetComponent<CharacterController>() != null ? 1.45f : 1.2f;
            Quaternion rotation = Quaternion.Euler(_pitch, _yaw, 0f);
            Vector3 focus = _target.position + Vector3.up * targetHeight;
            Vector3 desired = focus - rotation * Vector3.forward * distance;
            transform.position = Vector3.Lerp(transform.position, desired, 14f * Time.deltaTime);
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(focus - transform.position, Vector3.up), 14f * Time.deltaTime);
        }
    }
}
