#if UNITY_EDITOR
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using ProjectAfterlight.Core;

namespace ProjectAfterlight.Editor
{
    /// <summary>Creates project settings and a demo scene the first time the project is opened in Unity.</summary>
    [InitializeOnLoad]
    public static class AfterlightProjectSetup
    {
        private const string ScenePath = "Assets/ProjectAfterlight/Scenes/Afterlight_Demo.unity";
        private const string PipelinePath = "Assets/Settings/Afterlight_URP.asset";
        private const string RendererPath = "Assets/Settings/Afterlight_Renderer.asset";
        private static string SceneFullPath => Path.Combine(Directory.GetParent(Application.dataPath).FullName, ScenePath);
        private static bool _queued;

        static AfterlightProjectSetup()
        {
            if (_queued) return;
            _queued = true;
            EditorApplication.delayCall += AutoSetupIfRequired;
        }

        private static void AutoSetupIfRequired()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += AutoSetupIfRequired;
                return;
            }
            bool sceneMissing = !File.Exists(SceneFullPath);
            bool urpMissing = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath) == null;
            if (sceneMissing || urpMissing) SetupProject(false);
        }

        [MenuItem("PROJECT AFTERLIGHT/Setup Demo Scene + URP")]
        public static void SetupFromMenu() => SetupProject(true);

        private static void SetupProject(bool force)
        {
            if (!AssetDatabase.IsValidFolder("Assets/Settings")) AssetDatabase.CreateFolder("Assets", "Settings");
            if (!AssetDatabase.IsValidFolder("Assets/ProjectAfterlight/Scenes")) AssetDatabase.CreateFolder("Assets/ProjectAfterlight", "Scenes");
            ConfigureUrp();
            ConfigurePlayerSettings();
            if (force || !File.Exists(SceneFullPath)) CreateDemoScene();
            if (!EditorBuildSettings.scenes.Any(scene => scene.path == ScenePath && scene.enabled))
                EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("PROJECT AFTERLIGHT setup complete. Open Assets/ProjectAfterlight/Scenes/Afterlight_Demo.unity and press Play.");
        }


        private static void ConfigurePlayerSettings()
        {
            PlayerSettings.companyName = "Afterlight Studio";
            PlayerSettings.productName = "PROJECT AFTERLIGHT";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.afterlight.project");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
        }

        [MenuItem("PROJECT AFTERLIGHT/Build Android APK")]
        public static void BuildAndroidApk()
        {
            SetupProject(false);
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                EditorUtility.DisplayDialog("Android module missing", "Install Android Build Support (SDK/NDK + OpenJDK) for this Unity version in Unity Hub, then try again.", "OK");
                return;
            }
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
            {
                bool switched = EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
                Debug.Log(switched
                    ? "Android build target switched. After Unity finishes importing, run PROJECT AFTERLIGHT > Build Android APK again."
                    : "Could not switch to Android. Switch platform manually in Build Profiles.");
                return;
            }

            var scenes = EditorBuildSettings.scenes.Where(scene => scene.enabled).Select(scene => scene.path).ToArray();
            if (scenes.Length == 0)
            {
                EditorUtility.DisplayDialog("No build scenes", "Run PROJECT AFTERLIGHT > Setup Demo Scene + URP first.", "OK");
                return;
            }
            const string outputRelativePath = "Builds/Android/ProjectAfterlight.apk";
            string outputPath = Path.Combine(Directory.GetParent(Application.dataPath).FullName, outputRelativePath);
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result == BuildResult.Succeeded)
                Debug.Log("PROJECT AFTERLIGHT APK built: " + outputPath + " | Size: " + report.summary.totalSize + " bytes");
            else
                Debug.LogError("PROJECT AFTERLIGHT APK build failed: " + report.summary.result + " | " + report.summary.totalErrors + " error(s)");
        }

        private static void ConfigureUrp()
        {
            var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
            if (pipeline == null)
            {
                pipeline = ScriptableObject.CreateInstance<UniversalRenderPipelineAsset>();
                var renderer = pipeline.LoadBuiltinRendererData();
                if (renderer != null && AssetDatabase.LoadAssetAtPath<ScriptableRendererData>(RendererPath) == null)
                    AssetDatabase.CreateAsset(renderer, RendererPath);
                AssetDatabase.CreateAsset(pipeline, PipelinePath);
            }
            GraphicsSettings.defaultRenderPipeline = pipeline;
            QualitySettings.renderPipeline = pipeline;
            EditorUtility.SetDirty(pipeline);
        }

        private static void CreateDemoScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("AFTERLIGHT_GAME_BOOTSTRAP");
            root.AddComponent<GameBootstrap>();
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
        }
    }
}
#endif
